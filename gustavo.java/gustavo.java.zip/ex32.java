public class Ex32 {
    public static void main(String[] args) {
        int i = 1;
        while (i <= 20) System.out.println(i++);
    }
}